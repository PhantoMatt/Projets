
import { createClient } from '@supabase/supabase-js'
const supabaseUrl = 'https://glrvigztmxkcyjukanxx.supabase.co'
const supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdscnZpZ3p0bXhrY3lqdWthbnh4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDkxMTUwNDUsImV4cCI6MjAyNDY5MTA0NX0.W5ZzUq3GphphHhLGCc8lXmoXIfSYLPLyZrUlyFrTmf4"
const supabase = createClient(supabaseUrl, supabaseKey)

async function getNotes(){
let { data, error } = await supabase
  .from('notes')
  .select()
  return { data, error }
}

async function getQuestions(){
  let { data, error } = await supabase
    .from('questions')
    .select()
    return { data, error }
  }

async function getNom(id){
  let { data, error } = await supabase
    .from('notes')
    .select('nom, prenom')
    .eq('id', id)
    return { data, error }
  }

async function addNom(info){
    let { data, error } = await supabase
      .from('notes')
      .insert(info)
      .select()
      return { data, error }
    }

export{getNotes, getNom, addNom, getQuestions}