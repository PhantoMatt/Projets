const soumettreBtn = document.querySelector('#soumettre')

soumettreBtn.addEventListener('click', function () {
    window.location.href = './index.html';
});