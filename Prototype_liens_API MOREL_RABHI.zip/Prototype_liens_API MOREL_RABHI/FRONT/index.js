import {obtQuestion} from "./fetch.js"

let i = 0
let nbr_Question
let bn_reponse
let reponse_choisie
let points = 0
let Tricherie = false
function displayQuestions(questionsData) {
    nbr_Question = questionsData.length;
    document.querySelector('#question').innerHTML = questionsData[i].enonce;
    document.querySelector('#a_reponse').innerHTML = questionsData[i].reponse_1;
    document.querySelector('#b_reponse').innerHTML = questionsData[i].reponse_2;
    document.querySelector('#c_reponse').innerHTML = questionsData[i].reponse_3;
    document.querySelector('#d_reponse').innerHTML = questionsData[i].reponse_4;
    bn_reponse = questionsData[i].bonne_reponse;
    
}


const reponses = document.querySelectorAll('.reponse')

const soumettreBtn = document.getElementById('soumettre')

soumettreBtn.addEventListener('click', function () {
    let Btn_radio = false;

    reponses.forEach(reponse => {
        if (reponse.checked) {
           Btn_radio = true;
           reponse_choisie = reponse.id;
        }
    });

    if (Btn_radio) {
        i++;
        if (bn_reponse == reponse_choisie) {
            points += 1
        }
        if (i < nbr_Question) {
            obtQuestion(displayQuestions)
            reponses.forEach(reponse => {
                reponse.checked = false;
            });
        } else {
            if (Tricherie == true){
                points = 0
                alert(`fin du quiz, vous avez ${points} points, vous avez tenté de tricher`)
            }
            else {
                alert(`fin du quiz, vous avez ${points} points`)
            }

        }
    }
});

window.addEventListener('blur', function() {
    Tricherie = true
});

window.addEventListener('keydown', function(event) {
    if ((event.ctrlKey && event.code === "KeyC") || (event.ctrlKey && event.code === "KeyV") || (event.ctrlKey && event.shiftKey)) {
        Tricherie = true
    }
});

window.addEventListener('contextmenu', function(event) {
    Tricherie = true
});


obtQuestion(displayQuestions)