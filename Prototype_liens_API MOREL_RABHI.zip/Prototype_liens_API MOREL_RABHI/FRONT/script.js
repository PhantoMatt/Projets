const quizBd = [
    {
        question : "",
        a:"",
        b:"",
        c:"",
        d:"",
        reponse:"d",
    },
    {
        question : "",
        a:"",
        b:"",
        c:"",
        d:"",
        reponse:"d",
    },
    {
        question : "",
        a:"",
        b:"",
        c:"",
        d:"",
        reponse:"d",
    },
    {
        question : "",
        a:"",
        b:"",
        c:"",
        d:"",
        reponse:"d",
    },
    {
        question : "",
        a:"",
        b:"",
        c:"",
        d:"",
        reponse:"d",
    }

];

const quiz = document.getElementById('quiz')

const reponses = document.getElementsByClassName('reponse')

const questions = document.getElementById('question')

const a_reponse = document.getElementById('a_reponse')
const b_reponse = document.getElementById('b_reponse')
const c_reponse = document.getElementById('c_reponse')
const d_reponse = document.getElementById('d_reponse')

const soumettreBtn = document.getElementById('soumettre')
