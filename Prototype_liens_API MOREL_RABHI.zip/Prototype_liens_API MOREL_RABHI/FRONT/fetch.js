async function obtQuestion(callback) {
    const res = await fetch('http://localhost:3000/api/v1/questions')
    const data = await res.json()
    const nbr_Question = data.length
    callback(data, nbr_Question)
}

export { obtQuestion };